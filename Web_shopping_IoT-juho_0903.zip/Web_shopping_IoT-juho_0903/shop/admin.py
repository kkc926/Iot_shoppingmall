from django.contrib import admin
from .models import Qna, Product

# Register your models here.
admin.site.register(Qna)
admin.site.register(Product)