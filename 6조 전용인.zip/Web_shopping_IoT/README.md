# Web_shopping_IoT
IoT 인터페이스개발용 git repo
************************************************
2020/08/14
-model 만들때

from django.contrib.auth.models import User
하지 말고

from register.models import User
로 바꿔야 서버 돌아감
************************************************
2020/08/13
- static 폴더->static_data/static
- media  폴더->static_data/media


